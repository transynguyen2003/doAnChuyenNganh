<ul>
		<li class="active"><a href="index.php">Home</a></li>
		<li><a href="index.php?quanly=about">About</a></li>
		<li><a href="index.php?quanly=styles">Styles</a></li>
		<li><a href="index.php?quanly=contact">Contact</a></li>
		<li><a href="index.php?quanly=thank">Thank You</a></li>
</ul>