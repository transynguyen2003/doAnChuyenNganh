<?php
$host = 'localhost';
$dbname = 'daweb'; // Tên database của bạn
$username = 'root';          // Username kết nối database
$password = '';              // Password kết nối database (để trống cho XAMPP/WAMP)

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Kết nối database thất bại: " . $e->getMessage());
}
?>
