document.addEventListener("DOMContentLoaded", () => {
    const id_sach = new URLSearchParams(window.location.search).get('id_sach');

    // Fetch sản phẩm từ backend
    fetch(`../main/product-detail.php?id_sach=${id_sach}`)
        .then(response => response.json())
        .then(data => {
            document.getElementById('product-image').src = `../images/${data.hinh_anh}`;
            document.getElementById('product-name').innerText = data.ten_sach;
            document.getElementById('product-author').innerText = data.tac_gia;
            document.getElementById('product-price').innerText = Number(data.gia_ban).toLocaleString();
            document.getElementById('product-desc').innerText = data.mo_ta;
        });

    // Thêm vào giỏ hàng
    document.getElementById('add-to-cart').addEventListener('click', () => {
        fetch(`../main/add-to-cart.php`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id_sach, so_luong: 1 })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert("Thêm vào giỏ hàng thành công!");
            } else {
                alert("Có lỗi xảy ra khi thêm vào giỏ hàng!");
            }
        });
    });
});
