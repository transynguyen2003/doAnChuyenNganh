<?php
// Include file kết nối cơ sở dữ liệu
require_once '../connect.php';

if (isset($_GET['query'])) {
    $query = trim($_GET['query']);

    try {
        // Tìm kiếm sách theo tên hoặc tác giả
        $sql = "SELECT * FROM sach WHERE ten_sach LIKE :query OR tac_gia LIKE :query";
        $stmt = $pdo->prepare($sql);
        $stmt->execute(['query' => '%' . $query . '%']);

        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        die("Lỗi: " . $e->getMessage());
    }
} else {
    $results = [];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kết quả tìm kiếm</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f9f9f9;
        }
        .results-container {
            max-width: 800px;
            margin: 50px auto;
        }
        .results-container h1 {
            text-align: center;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        table th, table td {
            padding: 10px;
            text-align: left;
            border: 1px solid #ddd;
        }
        table th {
            background-color: #007bff;
            color: white;
        }
        table td img {
            width: 100px;  /* Cố định kích thước hình ảnh */
            height: 100px;
            object-fit: cover;  /* Đảm bảo hình ảnh không bị biến dạng */
            border-radius: 5px;
        }
        table td button {
            padding: 8px 15px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        table td button:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>
    <div class="results-container">
        <h1>Kết quả tìm kiếm</h1>
        <?php if (!empty($results)): ?>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Tên sách</th>
                        <th>Tác giả</th>
                        <th>Giá bán</th>
                        <th>Mô tả</th>
                        <th>Số lượng</th>
                        <th>Hình ảnh</th>
                        <th>Ngày tạo</th>
                        <th>Chi tiết</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($results as $book): ?>
                        <tr>
                            <td><?= htmlspecialchars($book['id_sach']) ?></td>
                            <td><?= htmlspecialchars($book['ten_sach']) ?></td>
                            <td><?= htmlspecialchars($book['tac_gia']) ?></td>
                            <td><?= number_format($book['gia_ban'], 0, ',', '.') ?> VNĐ</td>
                            <td><?= htmlspecialchars($book['mo_ta']) ?></td>
                            <td><?= htmlspecialchars($book['so_luong']) ?></td>
                            <td>
                                <?php if (!empty($book['hinh_anh'])): ?>
                                    <img src="../images/<?php echo htmlspecialchars($book['hinh_anh']); ?>" alt="Ảnh sản phẩm">

                                <?php else: ?>
                                    Không có ảnh
                                <?php endif; ?>
                            </td>
                            <td><?= htmlspecialchars($book['ngay_tao']) ?></td>
                            <td><a href="../main/product-detail.php?id_sach=<?= $book['id_sach'] ?>"><button>Chi tiết</button></a></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>Không tìm thấy kết quả nào phù hợp.</p>
        <?php endif; ?>
    </div>
</body>
</html>
