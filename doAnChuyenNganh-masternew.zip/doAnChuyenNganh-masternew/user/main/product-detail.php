<?php
// Kết nối database bằng PDO
include("../connect.php"); // Đảm bảo đường dẫn chính xác đến file kết nối PDO

try {
    // Kiểm tra tham số id_sach
    if (isset($_GET['id_sach'])) {
        $id_sach = intval($_GET['id_sach']);
        $stmt = $pdo->prepare("SELECT * FROM sach WHERE id_sach = :id_sach");
        $stmt->bindParam(':id_sach', $id_sach, PDO::PARAM_INT);
        $stmt->execute();
        $sach = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$sach) {
            die("Sản phẩm không tồn tại!");
        }
    } else {
        die("ID sản phẩm không hợp lệ!");
    }
} catch (PDOException $e) {
    die("Lỗi: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chi Tiết Sản Phẩm</title>
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="container">
            <nav class="nav">
                <a href="../index.php">Trang chủ</a>
                <a href="cart.php">Giỏ hàng</a>
            </nav>
        </div>
    </header>

    <!-- Chi tiết sản phẩm -->
    <main class="product-detail">
        <div class="container">
            <div class="product-image">
                <img src="../images/<?php echo htmlspecialchars($sach['hinh_anh']); ?>" alt="Ảnh sản phẩm">
            </div>
            <div class="product-info">
                <h1 class="product-title"><?php echo htmlspecialchars($sach['ten_sach']); ?></h1>
                <p class="product-author"><strong>Tác giả:</strong> <?php echo htmlspecialchars($sach['tac_gia']); ?></p>
                <p class="product-price"><strong>Giá bán:</strong> <?php echo number_format($sach['gia_ban']); ?> VND</p>
                <p class="product-desc"><?php echo htmlspecialchars($sach['mo_ta']); ?></p>
                <form action="add_to_cart.php" method="POST">
                    <input type="hidden" name="id_sach" value="<?php echo $sach['id_sach']; ?>">
                    <button type="submit" class="btn">🛒 Thêm vào giỏ hàng</button>
                </form>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <p>&copy; 2024 BookSaw. Tất cả các quyền được bảo lưu.</p>
        </div>
    </footer>
</body>
</html>

