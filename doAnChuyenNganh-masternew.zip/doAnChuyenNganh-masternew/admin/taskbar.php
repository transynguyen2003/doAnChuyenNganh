<header class="d-flex justify-content-between align-items-center shadow-sm py-3 px-4">
<form action="search.php" method="GET">
    <input type="text" name="query" placeholder="Tìm kiếm sách..." required>
    <button type="submit">Tìm kiếm</button>
</form>

 </header>