<div class="col-md-2 sidebar">
                <h3 class="text-center brand-logo">NHASACHTV</h3>
                <nav>
                
                    <a href="#"><i class="fas fa-home me-2"></i>Trang Chủ</a>
                    <a href="index.php"><i class="fas fa-book me-2"></i>Sách</a>
                    <a href="index.php?act=tac_gia"><i class="fas fa-user me-2"></i>Tác Giả</a> 
                    <!-- tacGia.php?act=tacgia&this_id=tac_gia -->
                    <a href="index.php?act=danh_muc"><i class="fas fa-list me-2"></i>Danh Mục Sách</a>
                    <a href="index.php?act=dang_xuat"><i class="fas fa-sign-out-alt me-2"></i>Đăng Xuất</a>
                    
                </nav>
                <button class="btn btn-primary membership-btn">Become Membership</button>
                
            </div>

